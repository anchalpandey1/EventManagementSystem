export const DB_NAME = "EventManagement";
