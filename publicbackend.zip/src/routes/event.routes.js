import { Router } from "express";
import { createEvent,getEventsByUserId ,getAllEvents ,updateEvent, 
    deleteEvent } from "../controllers/Event.controller.js";
import upload from "../utils/multer.js";
import { validateRequestBody } from "../middlewares/validation.middleware.js";

const router = Router();
import { verifyJWT } from "../middlewares/auth.middleware.js";

//Admin Related
// router.route("/signup").post(upload.single("profile"), registerUser);
router.route("/createevent").post( createEvent);
router.route("/getlist/:userId").get(getEventsByUserId);
router.route("/getalllist").get( getAllEvents);
router.put('/update/:eventId', updateEvent);       
router.delete('/delete/:eventId', deleteEvent); 
export default router;
