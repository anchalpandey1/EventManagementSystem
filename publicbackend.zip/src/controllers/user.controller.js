import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { User } from "../models/user.model.js";
import { ApiResponse } from "../utils/ApiResponse.js";
import jwt from "jsonwebtoken";
import path from "path";
import { compressAndSaveImage } from "../utils/imgCompress.js";
import bcrypt from "bcrypt";
import dotenv from "dotenv";

dotenv.config();

const generateAccessAndRefereshTokens = async (userId) => {
    try {
        const user = await User.findById(userId);
        const accessToken = user.generateAccessToken();
        const refreshToken = user.generateRefreshToken();

        user.refreshToken = refreshToken;
        await user.save({ validateBeforeSave: false });

        return { accessToken, refreshToken };
    } catch (error) {
        throw new ApiError(
            500,
            "Something went wrong while generating referesh and access token"
        );
    }
};

// User Registration
const registerUser = asyncHandler(async (req, res) => {
    try {
        const { email, password, phoneNo, role} = req.body;

        // Validate required fields
        if (!email || !password || !phoneNo ) {
            return res.status(400).json({ message: "All fields are required" });
        }

        // Validate email format
        if (!/^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/.test(email)) {
            return res.status(400).json({ message: "Invalid email address" });
        }

       
        // Check if user already exists
        const existingUser = await User.findOne({ email });
        if (existingUser) {
            return res.status(400).json({ message: "Email already exists" });
        }

        // Create new user
        const newUser = new User({
            
            email,
            password,
            phoneNo,
            role: role , // Default role is "2" (user)
        });
        await newUser.save();

        // Generate access token
        const accessToken = jwt.sign(
            { _id: newUser._id, role: newUser.role },
            process.env.ACCESS_TOKEN_SECRET,
            { expiresIn: process.env.ACCESS_TOKEN_EXPIRY }
        );

        res.status(201).json({
            message: "User registered successfully",
            accessToken,
            user: { _id: newUser._id,  email: newUser.email,phoneNo:newUser.phoneNo, role: newUser.role },
        });
    } catch (error) {
        res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});

//user Login
const loginUser = asyncHandler(async (req, res) => {
  const { email, password } = req.body;

  if (!password && !email) {
      return res
          .status(400)
          .json(new ApiError(400, null, "password or email is required"));
  }

  const user = await User.findOne({
      $or: [{ email }],
  });
  if (!user) {
      return res
          .status(404)
          .json(new ApiError(404, null, "User does not exist"));
  }
console.log(user);
  const isPasswordValid = await user.isPasswordCorrect(password);

  if (!isPasswordValid) {
      return res
          .status(401)
          .json(new ApiError(401, null, "Invalid user credentials"));
  }

  const { accessToken, refreshToken } = await generateAccessAndRefereshTokens(
      user._id
  );

  const loggedInUser = await User.findById(user._id).select(
      "-password   -refreshToken -createdAt -updatedAt -__v"
  );

  const options = {
      httpOnly: true,
      secure: true,
  };

  return res
      .status(200)
      .cookie("accessToken", accessToken, options)
      .cookie("refreshToken", refreshToken, options)
      .json(
          new ApiResponse(
              200,
              loggedInUser,
              "userInfo",
              "User logged In Successfully",
              accessToken,
              refreshToken
          )
      );
});


const getCurrentUser = asyncHandler(async (req, res) => {
    // Get the access token from the cookie
    const accessToken = req.cookies.accessToken;

    // If access token is not found, return an error
    if (!accessToken) {
        return res.status(401).json(new ApiError(401, null, "Access token is required"));
    }

    try {
        // Verify and decode the access token
        const decoded = jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET);

        // Find the user by ID from the decoded token
        const user = await User.findById(decoded._id).select("-password -refreshToken -createdAt -updatedAt -__v");

        // If user not found, return an error
        if (!user) {
            return res.status(404).json(new ApiError(404, null, "User not found"));
        }

        // Respond with the user data (excluding sensitive fields like password and refreshToken)
        return res.status(200).json(new ApiResponse(200, user, "userInfo", "User data fetched successfully"));
    } catch (error) {
        // If token is invalid or expired, return an error
        return res.status(401).json(new ApiError(401, null, "Invalid or expired access token"));
    }
});





export {
    registerUser,
    loginUser,
    getCurrentUser
};
