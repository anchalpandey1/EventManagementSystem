// import { ApiError } from "../utils/ApiError.js";
// import { ApiResponse } from "../utils/ApiResponse.js";
// import { asyncHandler } from "../utils/asyncHandler.js";
// import { Event } from "../models/Event.model.js";

// const createEvent = asyncHandler(async (req, res) => {
//     const { userid } = req.params;
//     const { name, description, organizer, date, time } = req.body;

//     // Validate required fields
//     if (!name || !organizer || !time) {
//         throw new ApiError(400, "Name, Organizer, and Time are required fields.");
//     }

//     // Create a new event
//     const event = await Event.create({
//         name,
//         description,
//         organizer,
//         userid,
//         date,
//         time
//     });

//     res.status(201).json(new ApiResponse(201, event, "Event created successfully"));
// });

// export { createEvent };


import { asyncHandler } from "../utils/asyncHandler.js";
import { ApiError } from "../utils/ApiError.js";
import { Event } from "../models/Event.model.js";
import { User } from "../models/user.model.js";
import jwt from "jsonwebtoken";

// Create Event (for event organizers)
const createEvent = asyncHandler(async (req, res) => {
    const { name, description, date, time, organizer } = req.body;

    // Validate required fields
    if (!name || !time || !organizer) {
        return res.status(400).json({ message: "All fields are required" });
    }

    // Get the access token from the cookies
    const accessToken = req.cookies.accessToken;

    if (!accessToken) {
        return res.status(401).json(new ApiError(401, null, "Access token is required"));
    }

    try {
        // Verify and decode the access token to get the user ID
        const decoded = jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET);

        // Check if the user is an event organizer
        const user = await User.findById(decoded._id);

        if (!user) {
            return res.status(404).json(new ApiError(404, null, "User not found"));
        }

        if (user.role !== "1") { // role "1" is for event organizers
            return res.status(403).json(new ApiError(403, null, "Only event organizers can create events"));
        }

        // Create a new event
        const newEvent = new Event({
            name,
            description,
            date,
            time,
            organizer,
            userid: user._id,  // Associate the event with the logged-in user
        });

        await newEvent.save();

        return res.status(201).json({
            message: "Event created successfully",
            event: newEvent,
        });
    } catch (error) {
        return res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});



const getEventsByUserId = asyncHandler(async (req, res) => {
    const { userId } = req.params;

    try {
        // Fetch events created by the user
        const events = await Event.find({ userid: userId }).exec();

        if (!events.length) {
            return res.status(404).json(new ApiError(404, null, "No events found for this user"));
        }

        return res.status(200).json({
            message: "Events fetched successfully",
            data: events,
        });
    } catch (error) {
        return res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});


const getAllEvents = asyncHandler(async (req, res) => {
    try {
        // Fetch all events
        const events = await Event.find().exec();

        if (!events.length) {
            return res.status(404).json(new ApiError(404, null, "No events found"));
        }

        return res.status(200).json({
            message: "All events fetched successfully",
            data: events,
        });
    } catch (error) {
        return res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});


// Update Event
const updateEvent = asyncHandler(async (req, res) => {
    const { eventId } = req.params; // Event ID from request params
    const { name, description, date, time, organizer } = req.body;

    // Validate required fields
    if (!name || !time || !organizer) {
        return res.status(400).json({ message: "Name, Time, and Organizer are required fields" });
    }

    // Get the access token from the cookies
    const accessToken = req.cookies.accessToken;

    if (!accessToken) {
        return res.status(401).json(new ApiError(401, null, "Access token is required"));
    }

    try {
        // Verify and decode the access token to get the user ID
        const decoded = jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET);

        // Find the event by ID
        const event = await Event.findById(eventId);

        if (!event) {
            return res.status(404).json(new ApiError(404, null, "Event not found"));
        }

        // Check if the logged-in user is the organizer of the event
        if (event.userid.toString() !== decoded._id.toString()) {
            return res.status(403).json(new ApiError(403, null, "You can only update your own events"));
        }

        // Update the event with the new details
        event.name = name || event.name;
        event.description = description || event.description;
        event.date = date || event.date;
        event.time = time || event.time;
        event.organizer = organizer || event.organizer;

        await event.save();

        return res.status(200).json({
            message: "Event updated successfully",
            event,
        });
    } catch (error) {
        return res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});

// Delete Event
// Delete Event
const deleteEvent = asyncHandler(async (req, res) => {
    const { eventId } = req.params; // Event ID from request params

    // Get the access token from the cookies
    const accessToken = req.cookies.accessToken;

    if (!accessToken) {
        return res.status(401).json(new ApiError(401, null, "Access token is required"));
    }

    try {
        // Verify and decode the access token to get the user ID
        const decoded = jwt.verify(accessToken, process.env.ACCESS_TOKEN_SECRET);

        // Find the event by ID
        const event = await Event.findById(eventId);

        if (!event) {
            return res.status(404).json(new ApiError(404, null, "Event not found"));
        }

        // Check if the logged-in user is the organizer of the event
        if (event.userid.toString() !== decoded._id.toString()) {
            return res.status(403).json(new ApiError(403, null, "You can only delete your own events"));
        }

        // Delete the event using deleteOne
        await Event.deleteOne({ _id: eventId });

        return res.status(200).json({
            message: "Event deleted successfully",
        });
    } catch (error) {
        return res.status(500).json({ message: "Internal Server Error", error: error.message });
    }
});


export { createEvent ,
    getEventsByUserId,
    getAllEvents,
    updateEvent, 
    deleteEvent 
};
